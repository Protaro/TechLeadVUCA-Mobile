package com.example.sharedpreferences.firebase

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.DocumentSnapshot
import kotlinx.coroutines.tasks.await

class FirebaseHelper {
    private val firestore = FirebaseFirestore.getInstance()
    private val studentCollection = firestore.collection("students")

    // Fetch student names based on a search pattern
    suspend fun getStudentNames(query: String): List<String> {
        val snapshot = studentCollection
            .whereGreaterThanOrEqualTo("name", query)
            .whereLessThan("name", query + "\uf8ff")
            .get()
            .await()

        return snapshot.documents.mapNotNull { it.getString("name") }
    }

    // Fetch the student number by name
    suspend fun getStudentNumberByName(name: String): String? {
        val snapshot = studentCollection
            .whereEqualTo("name", name)
            .get()
            .await()

        return snapshot.documents.firstOrNull()?.getString("studentNumber")
    }

    // Fetch the student by student number
    suspend fun getNameByStudentNumber(studentNumber: String): String? {
        val snapshot = studentCollection
            .whereEqualTo("studentNumber", studentNumber)
            .get()
            .await()

        return snapshot.documents.firstOrNull()?.getString("name")
    }

    // Add a new entry
    suspend fun addStudent(name: String, studentNumber: String, timestamp: String) {
        val newStudent = hashMapOf(
            "name" to name,
            "studentNumber" to studentNumber,
            "timestamp" to timestamp
        )

        studentCollection.add(newStudent).await()
    }
}
