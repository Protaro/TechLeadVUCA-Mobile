package com.example.sharedpreferences.ui.dashboard

import androidx.lifecycle.ViewModel

class DashboardViewModel : ViewModel() {
    // No changes needed for now
}
