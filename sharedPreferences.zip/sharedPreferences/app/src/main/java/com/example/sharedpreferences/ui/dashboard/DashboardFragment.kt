package com.example.sharedpreferences.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.sharedpreferences.databinding.FragmentDashboardBinding
import com.example.sharedpreferences.firebase.FirebaseHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.*

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private val firebaseHelper = FirebaseHelper()
    private lateinit var nameAutoCompleteAdapter: ArrayAdapter<String>

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        val root: View = binding.root

        // Set up the AutoCompleteTextView for name input
        nameAutoCompleteAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, mutableListOf())
        binding.idEdtName.setAdapter(nameAutoCompleteAdapter)

        // Watch for changes in the name field
        binding.idEdtName.addTextChangedListener { text ->
            val query = text.toString()
            if (query.isNotEmpty()) {
                fetchNameSuggestions(query)
            }
        }

        // Watch for changes in the student number field
        binding.idEdtStudentNumber.addTextChangedListener { text ->
            val query = text.toString()
            if (query.isNotEmpty()) {
                fetchNameByStudentNumber(query)
            }
        }

        // Add data to Firebase when the button is clicked
        binding.idBtnAddRow.setOnClickListener {
            val name = binding.idEdtName.text.toString().trim()
            val studentNumber = binding.idEdtStudentNumber.text.toString().trim()

            if (name.isNotEmpty() && studentNumber.isNotEmpty()) {
                addStudentToTable(name, studentNumber)
            } else {
                Toast.makeText(requireContext(), "Please fill both fields", Toast.LENGTH_SHORT).show()
            }
        }

        return root
    }

    private fun fetchNameSuggestions(query: String) {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val names = firebaseHelper.getStudentNames(query)
                nameAutoCompleteAdapter.clear()
                nameAutoCompleteAdapter.addAll(names)
                nameAutoCompleteAdapter.notifyDataSetChanged()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun fetchNameByStudentNumber(studentNumber: String) {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val name = firebaseHelper.getNameByStudentNumber(studentNumber)
                if (!name.isNullOrEmpty()) {
                    binding.idEdtName.setText(name)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun addStudentToTable(name: String, studentNumber: String) {
        // Get current timestamp
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

        // Add data to the Firestore database
        CoroutineScope(Dispatchers.Main).launch {
            try {
                firebaseHelper.addStudent(name, studentNumber, timestamp)
                displayInTable(name, studentNumber, timestamp)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun displayInTable(name: String, studentNumber: String, timestamp: String) {
        val tableRow = TableRow(requireContext())

        val nameTextView = TextView(requireContext()).apply {
            text = name
            setPadding(10, 10, 10, 10) // Use setPadding for TextView
        }

        val studentNumberTextView = TextView(requireContext()).apply {
            text = studentNumber
            setPadding(10, 10, 10, 10)
        }

        val timestampTextView = TextView(requireContext()).apply {
            text = timestamp
            setPadding(10, 10, 10, 10)
        }

        tableRow.apply {
            addView(nameTextView)
            addView(studentNumberTextView)
            addView(timestampTextView)
        }

        binding.idTableLayout.addView(tableRow)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
